function todoUserInterface() {
  function showTodoItem(newId, newDescription) {}
  function showNumberOfDone(numberOfDone) {}
  function showNumberOfNotDone(numberOfNotDone) {}
  return { showTodoItem, showNumberOfDone, showNumberOfNotDone }
}
module.exports = todoUserInterface
