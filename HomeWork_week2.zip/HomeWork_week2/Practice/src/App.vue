<!-- v-html
v-bind
v-show
v-if -->
<script setup>
import info from "../PriceAll.json";
  let infoMath = info.map(e => e.amount  )
  let sum = infoMath.reduce((a,b) => a+b)
</script>

<template>
  <h2 class="text-center font-bold">MY ACCOUNT</h2>
  <div class="max-sm:hidden">
  <div class="w-full flex justify-between">
    <div class="font-bold">Name</div>
    <div class="font-bold">Amount</div>
  </div>
  <div class="w-full flex justify-between" v-for="({ name, amount }, index) in info" :key="index" v-show="amount !== 0">
      <div >{{ name }}</div>
      <div :class="amount < 0?'bg-red-300': 'bg-green-300'">{{ amount }}</div>
  </div>
  <div class="w-full flex justify-between" >
    <div class="text-left font-bold capitalize">Net Total:</div>
     <div class="text-right font-bold">{{ sum.toLocaleString() }}</div> 
  </div>
</div>
 
  <!-- ------------------------------------------------------------------------------------------------------------------------ -->
  <div class="sm:hidden">
  <div class="w-full border-2 rounded-lg" v-for="({ name, amount }, index) in info" :key="index" v-show="amount !== 0" >
    <br><div class="mx-10 px-30  ">Name: {{ name }}</div>
      <div class="mx-10 px-30  " >Amount: <span  :class="amount < 0?'border-2 rounded-lg bg-red-300': 'border-2 rounded-lg bg-green-300' ">{{ amount }}</span></div>
  </div><br>
  <div class="w-full flex justify-between border-2 rounded drop-shadow-2xl  " >
    <div class="font-bold mx-10 px-30 ">Net Total: <span class='px-30 mx-10'>{{ sum.toLocaleString() }}</span></div>
  </div>
</div>

</template>

<style scoped>
</style>
