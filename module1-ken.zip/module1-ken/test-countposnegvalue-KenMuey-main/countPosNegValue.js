const { template } = require('@babel/core')
//64130500083 Saharat kanuenghade
function countPosNegValue(posNegIntegerArray) {
  let result = {}
  if(posNegIntegerArray === null || posNegIntegerArray === undefined){return undefined}
  if(posNegIntegerArray.length === 0){return {}}
  let pos = posNegIntegerArray.filter(e => e > 0).length
  let neg = posNegIntegerArray.filter(e => e < 0).length
  if(pos === 0){result['positive'] = 0}
  if(neg === 0){result['negative'] = 0}
  if(pos){result['positive'] = pos}
  if(neg){result['negative'] = neg}
  return result
}
module.exports = countPosNegValue
