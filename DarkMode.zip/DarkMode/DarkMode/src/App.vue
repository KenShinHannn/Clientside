!<script setup>
import {ref} from 'vue'
const darkTheme = ref(false)
const yourColor = ref('ffdbdb')
const studentId = ref('')
const entryYear = ref('')
const findEntryYear=(e, digit)=>{
  entryYear.value=studentId.value.substring(0,digit)
  console.log(e.target.id);
  console.log(e.target.name);
  console.log(e.target.tagName);
}
const dyImage = 'images/bathroom.jpg'
</script>
 
<template> 
  <div class="w-full h-screen flex-col favoriteBg" >
   <div>
    <div class="w-full flex space-x-2" >
      <h3>Your Favorite Color:</h3>
      <input type="color" v-model="yourColor"/>{{ yourColor }}
    </div>
    <div  class="w-full flex space-x-2 justify-end p-2">
  <h1>DarkMode</h1>
  <input v-model="darkTheme" type="checkbox" class="toggle" checked />{{ darkTheme }}
  </div>
</div>
  <div class="w-full flex-col space-x-2">
    <div class="flex space-x-2">
      <label for="">Student Id:</label>
      <input type="text" placeholder="64xxxxxxxxx" 
      class="border border-gray-300 p-1"
      v-model="studentId"
      @keyup.enter="findEntryYear($event, 3)"/>
      <!-- <button 
      @click="findEntryYear($event,3)" 
      id="btn-001" name="findEntryYearButton"
      class="rounded-xl bg-emerald-200 text-white p-1">OK</button> -->
    </div>
    <div class="flex space-x-2">
      <p>Entry Year: <span>{{ entryYear }}</span></p>
    </div>
  </div>
  <div class="w-full flex-col">
    <div class="flex">
      <h3>Static Image:</h3>
      <img src="./assets/logo.svg" alt="" 
      class="w-40 h-20">
      </div>
    <div class="flex">
      <h3>Dynamic Image:</h3>
      <img :src="dyImage" class="w-32 h-32"/>
      </div>
  </div>
</div>
</template>
 
<style scoped>
.dark{
  background-color: black;
  color:white;
}
.light{
  background-color: white;
  color: black;
}
.favoriteBg{
  background-color: v-bind(yourColor);
}
</style>