<script setup>
import { ref, reactive, computed } from 'vue'
import IonIosSearch from './components/icons/SimpleLineIconsMagnifier.vue'
import groupworks from '../groupworks.json'
const filteredGroupworks = computed(() => {
    console.log(groupworks)
    return groupworks.filter((group) =>
        group.projectName.toLowerCase().includes(searchKeyword.value.toLowerCase())
    )
})
const searchKeyword = ref('')
const footer =
    '<span class="text-yellow-600">School of Information Technology, KMUTT</span>'
const getFooter = (type) => {
    let courseName = 'INT203 Client Side II'
    if (type.toLowerCase() === 'long') return `${courseName}, ${footer}`
    else return footer
}
const searchDisable = true
const courseId = 'INT206'
let notRefData = 0 //this variable is not a reactive data
const refData = ref(0) //this variable is a reactive data
const incrementNotRefData = () => {
    notRefData = notRefData + 1
    console.log(notRefData)
}
// const groups = reactive(groupworks)
// console.log(groups)
// const groupRef = ref(groupworks)
// console.log(groupRef.value)
const yourName = ref('')
const yourSurname = ref('')
const agree = ref(false)
const search = ref(false)

</script>
<template>
    <div class="w-full">
        <div class="w-full flex flex-col">
            <div>
                <input type="checkbox" v-model="agree" />
                I {{ agree ? 'agree' : 'not agree' }} the term and use
            </div>
            <div class="flex flex-col">
                <div>
                    yourName:
                    <input
                        type="text"
                        v-model="yourName"
                        class="border border-gray-500"
                    />
                    {{ yourName }}
                </div>
                <div>
                    yourSurname:
                    <input
                        v-model="yourSurname"
                        type="text"
                        class="border border-gray-500"
                    />
                    {{ yourSurname }}
                </div>
            </div>
            <div>
                <div class="flex">
                    <p>Not Ref Data: {{ notRefData }}</p>
                    <button
                        v-on:click="incrementNotRefData"
                        class="border border-gray-500 p-1"
                    >
                        +
                    </button>
                </div>
                <div class="flex">
                    <p>Ref Data: {{ refData }}</p>
                    <button @click="refData++" class="border border-gray-500 p-1">
                        +
                    </button>
                </div>
            </div>
            <!-- column#1 header -->
            <div class="w-full flex flex-row">
                <!-- #1 -->
                <img src="./assets/vuelogo.ico" class="w-14 h-12 m-3" />
                <!-- #2 -->
                <div class="w-full flex flex-col p-2">
                    <h1 class="text-emerald-500 tracking-widest font-semibold text-xl">
                        Vue3 Group Projects
                    </h1>
                    <h3 class="italic" v-if="courseId.toLowerCase() === 'int203'">
                        Part of Learning Activities for INT203-Client Side Programming II
                    </h3>
                    <h3 class="italic" v-else-if="courseId.toLowerCase() === 'int205'">
                        Part of Learning Activities for INT205-Client Side Programming I
                    </h3>
                    <h3 class="italic" v-else-if="courseId.toLowerCase() === 'int204'">
                        Part of Learning Activities for INT204-Server Side Programming I
                    </h3>
                    <h3 class="italic" v-else="courseId.toLowerCase() === 'int206'">
                        Part of Learning Activities for INT206-Database
                    </h3>
                </div>
                <!-- #3 -->
                <div
                    class="w-full flex flex-row space-x-2 justify-end p-2 items-center"
                    v-show="true"
                >
                    <IonIosSearch @click="search = !search" />
                    <div class="flex" v-show="search">
                        <input
                            v-model.trim="searchKeyword"
                            type="text"
                            class="outline-none rounded-lg border border-gray-200 p-1"
                            placeholder="Type your keyword here..."
                        />
                        {{ searchKeyword }}
                        <button
                            :class="searchDisable ? 'border-red-500' : 'border-green-500'"
                            class="rounded-md border p-1"
                            :disabled="searchDisable"
                        >
                            Search
                        </button>
                    </div>
                </div>
            </div>
            <!-- column#2 table -->
            <div class="w-full mt-5">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b-2 border-gray-200">
                        <th class="font-semibold tracking-wide p-3 text-sm text-left">
                            Section
                        </th>
                        <th class="font-semibold tracking-wide p-3 text-sm text-left">
                            Project Name
                        </th>
                        <th class="font-semibold tracking-wide p-3 text-sm text-left">
                            GitHub Repo
                        </th>
                        <th class="font-semibold tracking-wide p-3 text-sm text-left">
                            Group Members
                        </th>
                    </thead>
                    <tbody>
                        <tr
                            :class="index % 2 === 0 ? 'bg-gray-100' : 'bg-white'"
                            v-for="(
                                { section, projectName, githubRepo, students }, index
                            ) in filteredGroupworks"
                            :key="index"
                        >
                            <td>{{ section }}</td>
                            <td>{{ projectName }}</td>
                            <td>{{ githubRepo }}</td>
                            <td>
                                <div class="w-full flex flex-col">
                                    <p v-for="student in students" :key="student.id">
                                        {{ student.id }} {{ student.name }}
                                    </p>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- column#3 -->
            <div
                class="w-full flex justify-center text-xs text-gray-400 mt-10"
                v-html="getFooter('short')"
            ></div>
        </div>
    </div>
</template>
<style scoped></style>